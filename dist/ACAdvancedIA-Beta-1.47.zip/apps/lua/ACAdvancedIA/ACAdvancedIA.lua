-- Reprise d'une mise à jour interrompue (Beta 1.35), avant tout autre module : une copie arrêtée au milieu (plantage,
-- coupure) aurait pu laisser des modules de deux versions ; elle est terminée ou défaite ici, de façon synchrone, avant
-- que les autres modules soient chargés. Seuls les deux modules de la mise à jour sont lus d'abord, chacun protégé.
-- Contrat figé (lu par toutes les versions à venir, voir src/update.lua) : Update.recover(port), Remote.new(onRelease),
-- port.ready, port.work, port.restart, port.log, port.bootOk, Update.recoverText.
local okUpdate,Update=pcall(require,'src/update')
local okRemote,Remote=pcall(require,'src/remote')
local onRelease
local port
if okUpdate and okRemote and type(Update)=='table' and type(Remote)=='table' then
 local ok,made=pcall(Remote.new,function() if onRelease then onRelease() end end)
 if ok and type(made)=='table' then port=made end
end
if not port then
 -- Modules de la mise à jour illisibles : l'app se charge sans mise à jour (port inerte, état affiché « non vérifié »).
 local function none() end
 local unread=okUpdate and okRemote and 'port' or tostring(not okUpdate and Update or Remote):sub(1,160)
 port={ready=false,work='',restart=none,log=none,bootOk=none,unreadable=unread}
 if not okUpdate or type(Update)~='table' then
  Update=setmetatable({new=function(version) return {phase='idle',installed=version,events={},serial=0,askedAt=0} end,
   view=function() return 'unchecked' end,take=function(_,out) return out end,checkGap=60,page=''},{__index=function() return none end})
  -- Beta 1.36 : le remplaçant est aussi celui que rend require('src/update') (interface) ; un second require d'un module
  -- en échec lèverait « loop or previous error loading module » et arrêterait le chargement de l'app.
  local loaded=_G.package and _G.package.loaded
  if loaded then loaded['src/update']=Update end
 end
end
local recovered
do
 local ok,result=pcall(function() return port.ready and Update.recover(port) or nil end)
 -- Sans reprise, result vaut nil : jamais « ok and result or … », qui prendrait alors l'échec.
 if ok then recovered=result else recovered={outcome='failed',failed=tostring(result):sub(1,120),file=port.work} end
end
-- Reprise dite tout de suite au journal de CSP : elle reste lisible même si un module ne se charge pas ensuite.
if recovered and port.ready then
 local okText,level,text=pcall(Update.recoverText,recovered)
 if okText and text then pcall(port.log,level..' '..text) end
end
-- Fichiers de l'app copiés à l'instant par la reprise : le code déjà chargé est celui d'une autre version. Aucun autre
-- module n'est lu ; l'app redémarre à la première image (compte rendu lu au lancement suivant).
if recovered and recovered.restart then
 local asked=false
 local function restartOnly() if not asked then asked=true; pcall(port.restart) end end
 function script.update() restartOnly() end
 function script.HUMANAI__UPDATE() restartOnly() end
 function script.HUMANAI__MAIN() end
 function script.HUMANAI__MENU() end
 function script.HUMANAI__FLAGS() end
 function script.HUMANAI__HUD() end
 return
end
local Snapshot=require('src/snapshot')
local Applier=require('src/applier')
local Engine=require('src/engine')
local Director=require('src/director')
local Caps=require('src/caps')
local Calibration=require('src/calibration')
local Zones=require('src/zones')
local UI=require('src/ui')
local U=require('src/util')
local Config=require('src/config')
local Lang=require('src/lang')
local Pits=require('src/pits')
local Penalties=require('src/penalties')
local Strategy=require('src/strategy')
local Sanctions=require('src/sanctions')
local Journal=require('src/journal')
local Locale=require('src/locale')
local Lights=require('src/lights')
local Cspgui=require('src/cspgui')
local Bridge=require('src/bridge')
local K=Config.K
-- Cache des traces du compilateur JIT agrandi (machine virtuelle de l'app) : avec les 1 000 traces et 512 Ko de code
-- machine par défaut, le moteur vide et recompile tout son code toutes les une à deux minutes (pics d'image). Sans
-- effet sur les décisions ; ignoré si la bibliothèque jit n'est pas exposée.
local jitlib=rawget(_G,'jit')
local jitTuned=type(jitlib)=='table' and type(jitlib.opt)=='table' and type(jitlib.opt.start)=='function' and pcall(jitlib.opt.start,'maxtrace=8000','maxmcode=16384')==true
local previous=rawget(_G,'HUMANAI')
if previous and type(previous.release)=='function' then pcall(previous.release) end
local host=Applier.new()
local globals,profiles=Applier.openStore(host)
-- Langue de l'interface choisie avant de préparer les textes de la fenêtre de réglages.
Locale.set(globals.language)
local engine=Engine.new(globals,profiles)
-- Voitures pilotées en un seul appel protégé seulement avec le cache agrandi (avec le cache par défaut, le code compilé
-- plus volumineux le saturerait plus vite).
engine.batchCars=jitTuned
local frame=Snapshot.new()
local calibration=Calibration.new()
local initialized=false
local released=false
local loadedTrack=''
-- Drapeau natif d'AC vu en dernier (Beta 1.34) : chaque changement est noté au journal (panneaux lumineux en jeu).
local nativeFlag=nil
local nativeFlagNames={[0]='aucun',[1]='depart',[2]='jaune',[3]='glissant',[5]='noir',[8]='penalite',[12]='bleu',[13]='damier',[14]='dernier tour'}
local lastCheckpoint=0
local shownMessage=0
-- Messages à l'écran : drapeaux, neutralisations, météo ; un seul affichage par événement.
local function announce()
 local t=engine.incidents
 if t.messageId==shownMessage then return end
 shownMessage=t.messageId
 local m=Lang.messages[t.messageKind]
 if m then
  local text=t.messageText~='' and string.format(m[2],t.messageText) or string.format(m[2],t.messageValue,t.messageExtra)
  -- Beta 1.41 : annonce de l'app, revenue par ac.onMessage : jamais prise pour un bandeau de pénalité d'AC.
  engine.ownTitle=m[1]; engine.ownText=text
  -- Beta 1.43 : annonce de sanction d'une IA (panneau dédié de l'overlay, jamais reprise en double).
  engine.ownAi=t.messageKind=='aiSanction' or t.messageKind=='aiBlackFlag'
  Applier.message(m[1],text)
 end
end
local function dirty()
 Applier.dirty(host,engine.time)
 if host.menuVisible then Applier.save(host,globals,profiles,engine.time,frame.replay,true) end
end
-- Messages d'AC (Beta 1.25) : écoute et masquage optionnel, annulés au déchargement.
local messageListener,messageBlock=nil,nil
local messages
local panel=UI.new(engine,host,calibration,dirty)
messageListener=Applier.listenMessages(function(title,description,kind,time) if not released then pcall(Engine.message,engine,title,description,kind,time) end end)
host.note=engine.note
-- Options de CSP tenues par l'app (Beta 1.40, src/cspgui.lua) : messages système et drapeaux d'origine d'AC masqués
-- tant que l'app est active (Beta 1.47 : laissées cochées à la fermeture, voir Cspgui.want). Fichiers lus et écrits dans update()
-- seulement (jamais pendant le dessin), au premier passage et à chaque changement de ce qui est voulu.
local cspPort=Applier.cspPort()
local csp=Cspgui.new()
Cspgui.start(csp,cspPort)
host.cspgui=csp; host.cspFrozen=function(key) return Cspgui.frozen(csp,key) end
local cspClock=0
local cspWant,cspEvents={},{}
local function cspLog()
 Cspgui.take(csp,cspEvents)
 for i=1,#cspEvents do local ev=cspEvents[i]; U.log(engine.log,engine.time or 0,ev[1],ev[2],-1); cspEvents[i]=nil end
end
-- CSP relit gui.ini (option changée en jeu, ou écrite par l'app) : état appliqué et drapeaux d'AC masqués relus.
local cspWatch=Applier.watchGui(function()
 if released then return end
 pcall(Cspgui.reloaded,csp,cspPort,cspClock); Applier.readFlagsHidden(host); cspLog()
end)
cspLog()
-- Démarrage surveillé d'une version tout juste installée (boot.txt, src/update.lua) : rien n'est écrit avant sa
-- confirmation (une relance de l'app par CSP à la relecture de gui.ini compterait comme un démarrage manqué).
local bootWatched=false
if port.ready and type(port.boot)=='function' then local okBoot,version=pcall(port.boot); bootWatched=okBoot and version~=nil end
local function cspStep(dt)
 if U.finite(dt) and dt>0 then cspClock=cspClock+math.min(dt,1) end
 -- Beta 1.47 : décision dans src/cspgui.lua (Cspgui.want) ; nil pendant la panique : rien ne change.
 Cspgui.step(csp,cspPort,Cspgui.want(globals,engine.p,engine.panic,cspWant),cspClock)
 cspLog()
end
-- AI flood de CSP (Beta 1.26) : état chargé par CSP au lancement ; le moteur écrit ensuite le réglage voulu.
do local user,system,writable=Applier.floodRead(); Engine.floodInit(engine,user,system,writable); engine.floodWrite=Applier.floodWrite end
if Applier.floodLeftover() then U.log(engine.log,0,'INFO','nettoyage: new_behaviour.ini.bak efface (reste d une version d avant la Beta 1.38)',-1) end
if host.storageErrors>0 then U.log(engine.log,0,'WARN','invalid_storage:'..host.storageErrors,-1) end
U.log(engine.log,0,'INFO',jitTuned and 'compilateur JIT: cache agrandi (8000 traces, 16 Mo), voitures pilotees en un seul appel protege' or 'compilateur JIT: options indisponibles, voitures pilotees une par une',-1)
if host.upgraded and #host.upgraded>0 then U.log(engine.log,0,'INFO','profils mis a jour vers les prereglages '..Config.release..': '..table.concat(host.upgraded,', '),-1) end
if host.signsRestored then U.log(engine.log,0,'INFO','sens lateral retabli: -1 / -1 (convention AC, mesure sur cette installation jusqu a la Beta 1.8 ; la mesure le confirmera)',-1) end
if host.firstInstall then U.log(engine.log,0,'INFO','premiere installation: prereglages recommandes et regles de base (essais, qualifications, course)',-1) end
local journal=Journal.new()
-- Journal de session sur disque : lignes nouvelles toutes les deux secondes, résumé chaque minute. Les capacités de CSP
-- perdues sont dites par l'applicateur (Applier.reportCaps), une seule fois.
local function writeJournal(force)
 if not globals.journal then return end
 if not host.journalTried then
  host.journalTried=true
  if Applier.journalOpen(host) then Applier.journalWrite(host,'=== ACAdvancedIA '..Config.release..' : lancement '..Applier.clockText()..' ===\n') end
 end
 if not host.journalPath or not force and engine.time<journal.flushAt then return end
 journal.flushAt=engine.time+K.journalPeriod
 -- Beta 1.47 : à la fermeture, résumé de la minute entamée (avant : perdu, le dernier contact d'une session n'y était pas).
 if engine.time>=journal.summaryAt or force and released and engine.time>journal.summaryAt-K.journalSummary+1 then journal.summaryAt=engine.time+K.journalSummary; U.log(engine.log,engine.time,'INFO',Journal.summary(engine),-1) end
 Journal.collect(journal,engine.log,Applier.clockText())
 Applier.journalWrite(host,Journal.take(journal))
end
local function cancelProbe() if host.allowed then Caps.cancelProbe(host.caps,frame) end end
local function syncRestored()
 for i=1,K.maxCars do
  local state=host.cars[i]
  if state.justRestored then
   Director.reset(engine.states[i],engine.time,false,true); engine.commands[i].active=false; engine.commands[i].offset=0
   state.justRestored=false
  end
 end
end
-- Une voiture au moins garde une commande de l'app à rendre.
local function anyOwned()
 for i=1,K.maxCars do if host.cars[i].owned then return true end end
 return false
end
-- Chaque étape de la restitution est protégée : une erreur dans l'une n'empêche jamais les suivantes.
local function step(fn,...)
 local ok,err=pcall(fn,...)
 if not ok then host.errors=host.errors+1; U.log(engine.log,engine.time,'ERROR','stop:'..tostring(err):sub(1,200),-1) end
end
-- keepParked : fin de session, voitures garées (voiture de sécurité, réserves, IA disqualifiées) laissées à leur stand
-- jusqu'à la session suivante ; jamais au déchargement.
local function stop(final,keepParked)
 if host.allowed then step(cancelProbe); step(Calibration.cancel,calibration,frame,host.caps,globals) end
 step(Applier.restore,host,frame,false,engine.time,final,keepParked); step(syncRestored); step(Applier.checkpoint,host,frame)
end
-- Arrêts et sanctions de la course : sauvegardés une seconde au plus après un changement, et au déchargement.
local lastRaceSave=0
local function saveRace(force)
 if not force and engine.time-lastRaceSave<K.saveDelay then return end
 lastRaceSave=engine.time
 if engine.pits.dirty then engine.pits.dirty=false; Applier.storeText('humanai:pits',Pits.serialize(engine.pits,frame.session)) end
 if engine.penalties.dirty then engine.penalties.dirty=false; Applier.storeText('humanai:penalties',Penalties.serialize(engine.penalties,frame,frame.session)) end
 -- Beta 1.42 : stratégie et sanctions des IA, gardées pour un rechargement de l'app en pleine course.
 if engine.strategy.dirty then engine.strategy.dirty=false; Applier.storeText('humanai:strategy',Strategy.serialize(engine.strategy,frame.session)) end
 if engine.sanctions.dirty then engine.sanctions.dirty=false; Applier.storeText('humanai:sanctions',Sanctions.serialize(engine.sanctions,frame.session)) end
end
-- Pont vers les apps compagnes (Beta 1.46, src/bridge.lua) : ouvert plus bas seulement si l'app lectrice est installée ;
-- fermé au déchargement (les lecteurs passent à « absent » aussitôt).
local bridge,bridgePort=nil,nil
local companion='SpotterEnginer'
local function release()
 if released then return end
 if bridgePort then pcall(Bridge.close,bridge,bridgePort.hello); bridgePort=nil end
 -- Aucune image ne suivra : restitution complète, y compris en pause ou en replay.
 released=true; Snapshot.read(frame,K.dtMax,engine.time); pcall(saveRace,true); Applier.access(host); stop(true); Applier.unregister(host)
 pcall(Applier.reportCaps,host)
 -- Overlay en jeu (Beta 1.25) : case de session d'AC et messages d'origine rendus, écoute des messages close.
 pcall(UI.restoreNative,panel); pcall(messages,false); Applier.dispose(messageListener); messageListener=nil
 -- Options de CSP (Beta 1.47) : laissées cochées, valeurs d'origine gardées (src/cspgui.lua).
 -- Retour arrière depuis l'app (vers une version qui ne connaît pas ces options) : rendues dans tous les cas.
 pcall(Cspgui.release,csp,cspPort,cspClock,host.updater~=nil and host.updater.after=='rollback'); Applier.dispose(cspWatch); cspWatch=nil; cspLog()
 pcall(writeJournal,true); Applier.journalWrite(host,'=== fin : '..Applier.clockText()..' ===\n')
end
-- Mise à jour depuis GitHub (Beta 1.33) : vérification une fois par lancement, installation d'un clic à l'arrêt. Avant
-- le redémarrage de l'app : événements versés au journal, puis restitution complète (commandes des IA rendues à AC).
-- Sans les fonctions de CSP (bancs de mesure, tests), le port est inerte et rien ne change.
local updater=Update.new(Config.release)
local updateEvents={}
local function updateLog()
 Update.take(updater,updateEvents)
 for i=1,#updateEvents do local ev=updateEvents[i]; U.log(engine.log,engine.time,ev[1],ev[2],-1); updateEvents[i]=nil end
end
onRelease=function() updateLog(); release() end
host.updater=updater; host.updatePort=port; host.updateStopped=false; host.updateNow=0
local updateClock,updateAsked,updateNoticed=0,false,false
-- Horloge de la mise à jour : temps réel (le temps du moteur est figé en pause et dans les menus, là où la fenêtre sert).
local updateNow,updateCounter=0,nil
-- Compte rendu de la reprise faite au chargement et de la dernière opération ; version précédente proposée.
if port.ready then Update.start(updater,port,recovered) end
updateLog()
-- Messages d'AC (Beta 1.25) : repris sur l'overlay ; leur affichage d'origine est masqué (Beta 1.26 : par défaut). Un
-- message témoin, envoyé dès le premier masquage, doit encore arriver à l'écoute : sinon (masquage qui couperait
-- aussi l'overlay), le masquage est levé jusqu'au prochain lancement et le journal le dit. Beta 1.40 : le témoin
-- vérifie aussi, une fois, les messages masqués par l'option de CSP (hide : option appliquée par CSP) ; s'ils
-- n'arrivent plus, l'option est rendue et ce choix gardé (cspMessagesLost, levé en recochant l'interrupteur).
local probe,unblockable=nil,false
local probeHide,hideProbed=false,false
local function startProbe(hide) engine.probeSeen=false; probe=Config.K.probeFrames; probeHide=hide; Applier.probeMessage(Config.K.messageProbe) end
messages=function(block,hide)
 if unblockable then block=false end
 if block and not messageBlock then
  messageBlock=Applier.blockMessages() or false
  if messageBlock and probe==nil then startProbe(hide==true) end
 elseif not block and messageBlock~=nil then Applier.dispose(messageBlock); messageBlock=nil end
 if hide and not hideProbed and type(probe)~='number' then startProbe(true) end
 if probe then
  if engine.probeSeen then
   probe=false; if probeHide then hideProbed=true end
   U.log(engine.log,engine.time or 0,'INFO','messages d AC: affichage d origine masque, messages repris sur l overlay'..(probeHide and ' (option de CSP comprise)' or ''),-1)
  else
   probe=probe-1
   if probe<=0 then
    probe=false
    if messageBlock then
     unblockable=true; Applier.dispose(messageBlock); messageBlock=nil
     U.log(engine.log,engine.time or 0,'WARN','messages d AC: les messages masques n arrivent plus a l overlay, masquage leve jusqu au prochain lancement',-1)
    end
    if probeHide then
     hideProbed=true; globals.cspMessagesLost=true; dirty()
     U.log(engine.log,engine.time or 0,'WARN',csp.owned.HIDE_SYSTEM_MESSAGES~=nil and 'messages d AC: masques par l option de CSP, ils n arrivent plus a l overlay: option rendue'
      or 'messages d AC: masques par l option de CSP, ils n arrivent plus a l overlay: decochez Hide system messages (CSP)',-1)
    end
   end
  end
 end
end
local function session()
 if released then return end
 Engine.reset(engine,engine.time,true); engine.session=-1; calibration.attempted=false; Pits.forget(engine.pits); Strategy.forget(engine.strategy); engine.penalties.pending=nil
 -- Beta 1.42 : point de reprise des sanctions oublié aussi (redémarrage au même indice) ; celui de la stratégie l'est par Strategy.forget.
 if engine.sanctions then engine.sanctions.pending=nil end
 host.session=nil -- Un redémarrage garde le même indice : les écritures suivies sont resynchronisées.
end
-- Beta 1.32 : panneaux lumineux du circuit cherchés dans sa configuration (et drapeaux d'AC masqués relus), une fois
-- par circuit.
local function lightsCheck()
 if host.trackLightsFor==frame.track then return end
 local lights=Applier.trackLights(host,frame.track)
 -- Beta 1.34 : places de grille du circuit (départ arrêté), lues en même temps.
 engine.grid.nodes=Applier.gridNodes(host,frame.track)
 U.log(engine.log,engine.time,'INFO',lights==true and 'panneaux lumineux du circuit: detectes ('..host.trackLightsSource..')' or lights==false and 'panneaux lumineux du circuit: non detectes'..(host.trackLightsDetail or '') or 'panneaux lumineux du circuit: configuration illisible',-1)
end
local function update(dt)
 if released then return end
 local valid=U.finite(dt) and dt>0 and dt<=K.dtMax
 local quiet=not globals.enabled
 if not quiet then
  quiet=true; for _,p in pairs(profiles) do if Config.any(p) then quiet=false; break end end
 end
 if quiet then
  if calibration.index>0 or host.caps.probeIndex>0 or host.flagOverride then quiet=false end
  for i=1,K.maxCars do if host.cars[i].owned then quiet=false; break end end
 end
 local read=Snapshot.read(frame,valid and dt or K.dtMax,engine.time,quiet)
 -- Drapeau du joueur imposé par l'app elle-même : le panneau ne le prend pas pour un drapeau natif.
 -- Beta 1.47 : aussi sa dernière valeur restée affichée après une restitution (Applier.flagMine).
 frame.flagOwned=Applier.flagMine(host,frame)
 if read and not frame.flagOwned and frame.flag~=nativeFlag then
  if nativeFlag~=nil or frame.flag~=K.flagNone then U.log(engine.log,engine.time,'INFO',string.format('drapeau d AC: %d (%s)',frame.flag,nativeFlagNames[frame.flag] or 'autre'),-1) end
  nativeFlag=frame.flag
 end
 if read then Applier.menu(host,frame.menu) else Applier.menu(host,Snapshot.menu()) end
 if not initialized then
  -- Session courante connue avant la récupération : un rechargement n'est pas un changement de session.
  initialized=true; host.session=frame.session; Applier.recover(host,frame)
  Pits.restore(engine.pits,Applier.loadText('humanai:pits'),frame.session)
  Penalties.restore(engine.penalties,Applier.loadText('humanai:penalties'),frame.session)
  Strategy.restore(engine.strategy,Applier.loadText('humanai:strategy'),frame.session)
  Sanctions.restore(engine.sanctions,Applier.loadText('humanai:sanctions'),frame.session)
  Applier.register(host,function() local ok=pcall(release); if not ok then host.errors=host.errors+1 end end,
   function() local ok=pcall(session); if not ok then host.errors=host.errors+1 end end)
 end
 Applier.baselines(host,frame)
 -- Départ arrêté (Beta 1.34) : retenue, plafond d'allure et décalage disponibles.
 engine.gridCaps=host.caps.stop.available and host.caps.speed.available and host.caps.offset.available
 -- Beta 1.41 : retenue à la sortie des stands seulement si l'arrêt natif répond.
 engine.stopCap=host.caps.stop.available==true
 engine.pitCap=host.caps.pit.available==true
 local ready=Engine.step(engine,frame,dt)
 Applier.reportCaps(host)
 if engine.settingsChanged then engine.settingsChanged=false; dirty() end
 writeJournal(false)
 if engine.rebaseDelta>0 then
  Applier.rebase(host,engine.rebaseDelta); calibration.startAt=calibration.startAt-engine.rebaseDelta
  frame.metaAt=frame.metaAt-engine.rebaseDelta; frame.playerDamageAt=frame.playerDamageAt-engine.rebaseDelta
  lastCheckpoint=lastCheckpoint-engine.rebaseDelta; lastRaceSave=lastRaceSave-engine.rebaseDelta
  journal.flushAt=journal.flushAt-engine.rebaseDelta; journal.summaryAt=journal.summaryAt-engine.rebaseDelta
 end
 if host.session~=frame.session then Applier.nextSession(host,frame) end
 if not valid or frame.online or frame.replay or frame.paused then return end
 -- Beta 1.34 : configuration du circuit lue aussi quand le moteur ne tourne pas (aucun onglet coché, app coupée).
 if not ready then lightsCheck() end
 if not ready and not engine.recalibrateRequested and calibration.index==0 and host.caps.probeIndex==0 then
  -- Drapeau natif imposé rendu à AC même sans voiture suivie (app désactivée, onglets décochés, rechargement).
  if not anyOwned() then
   if (host.flagOverride or host.flagLeftover) and Applier.access(host) then Applier.flag(host,frame,false) end
   -- DRS coupé par les règles (aucune voiture suivie pour autant) : rendu à toutes les voitures, joueur compris.
   if (host.drsAny or host.drsRelease) and Applier.access(host) then Applier.drs(host,frame,nil,engine.time); Applier.checkpoint(host,frame) end
   -- App désactivée : drapeau noir levé, la disqualification du joueur avec.
   if not globals.enabled and host.blackFlag and Applier.access(host) then
    Applier.releaseBlackFlag(host); if not host.blackFlag then engine.penalties.disqualified=false; engine.penalties.kind='slow' end
   end
   Applier.save(host,globals,profiles,engine.time,frame.replay); return
  end
 end
 local access=Applier.access(host)
 if not access then engine.guard='access'; return end
 if engine.recalibrateRequested then
  stop()
  if calibration.index>0 or anyOwned() then calibration.phase='waiting_reset'; return end
  globals.offsetSign=0; globals.sideSign=0; calibration.attempted=false; calibration.phase='waiting'
  engine.recalibrateRequested=false; Engine.reset(engine,engine.time,false); dirty()
 end
 if not ready then stop(false,engine.guard=='finished'); Applier.save(host,globals,profiles,engine.time,frame.replay); return end
 for i=1,frame.count do
  local state=engine.states[i]
  frame.cars[i].calibrationBlocked=state.state~='DRIVE' or state.excluded or engine.commands[i].active~=true
 end
 if loadedTrack~=frame.track then
  loadedTrack=frame.track; engine.zones={}; engine.zoneStart=-1; local data=Snapshot.zones(frame.track)
  lightsCheck()
  if data then
   local zones,err=Zones.parse(data)
   if zones then engine.zones=zones; U.log(engine.log,engine.time,'INFO','zones_loaded',-1)
   else U.log(engine.log,engine.time,'WARN','zones_rejected:'..err,-1) end
  end
 end
 Applier.restore(host,frame,true,engine.time)
 syncRestored()
 local probeBefore=host.caps.probeIndex
 if Config.on(engine.p,'general') then Caps.probe(host.caps,frame,engine.time,engine.runtimeG)
 else cancelProbe(); Caps.mode(host.caps,engine.runtimeG) end
 if probeBefore==0 and host.caps.probeIndex>0 then
  local index=host.caps.probeIndex; local s=host.cars[index]; local car=frame.cars[index]
  if not s.owned then s.owned=true; s.id=car.identity or car.id; s.originalLevel=host.caps.probeOriginal; s.originalAggression=car.aiAggression end
  s.level=K.probeLevel; host.recoveryDirty=true; Applier.checkpoint(host,frame)
 elseif probeBefore>0 and host.caps.probeIndex==0 then
  -- Fin de sonde : le niveau d'origine vient d'être réécrit ; le suivi d'écriture le reflète.
  local s=host.cars[probeBefore]
  if s.owned and s.level~=nil then s.level=host.caps.probeOriginal; s.levelAt=engine.time end
 end
 local signBefore=globals.offsetSign
 if Config.needsOffset(engine.run) then Calibration.step(calibration,frame,host.caps,globals,engine.time)
 elseif calibration.index>0 then stop() end
 if signBefore~=globals.offsetSign and globals.offsetSign~=0 then U.log(engine.log,engine.time,'INFO',string.format('sens lateral mesure: %d / %d',globals.offsetSign,globals.sideSign),-1) end
 if signBefore~=globals.offsetSign or engine.settingsChanged then engine.settingsChanged=false; dirty() end
 if calibration.index>0 then
  local index=calibration.index; engine.commands[index].active=false
  local s=host.cars[index]; local car=frame.cars[index]
  if not s.owned then s.owned=true; s.id=car.identity or car.id; s.originalLevel=car.aiLevel; s.originalAggression=car.aiAggression end
  s.offset=K.calibrationOffset
  s.offsetReset=false
  if engine.time==calibration.startAt then host.recoveryDirty=true; Applier.checkpoint(host,frame) end
 end
 Config.effectiveGlobals(globals,engine.p,engine.runtimeG)
 host.calibrationIndex=calibration.index
 Applier.apply(host,frame,engine.commands,engine.runtimeG,engine.time)
 -- Drapeau du joueur : panneaux lumineux du circuit (section du profil en cours, circuit équipé) ; sinon jaune natif du
 -- HUD sur demande.
 local lightsOn=Config.on(engine.run,'lights') and host.trackLights==true
 local flagValue,flagReason=Lights.output(engine.lights,engine.incidents,lightsOn)
 Applier.flag(host,frame,flagValue,flagReason,lightsOn and engine.time or nil,engine.run.lightsHold)
 Applier.penalty(host,frame,engine.penalties)
 Applier.beep(host,frame,engine.drs)
 Applier.deltaBeep(host,frame,engine.deltaBeep)
 Applier.drs(host,frame,engine.commands,engine.time)
 announce()
 local periodic=engine.time-lastCheckpoint>=K.saveDelay
 if host.recoveryDirty or periodic then lastCheckpoint=engine.time; Applier.checkpoint(host,frame,periodic) end
 saveRace(false)
 Applier.save(host,globals,profiles,engine.time,frame.replay)
end
-- Mise à jour : vérification au lancement (après K.updateDelay s), état « à l'arrêt » pour l'installation (pause, menu
-- ou stands) ; information de l'overlay une fois par lancement, aux stands seulement, retirée dès la sortie.
local function updateTick(dt)
 if not port.ready then return end
 local step=U.finite(dt) and dt>0 and dt<=K.dtMax and dt or 0
 if U.finite(dt) and dt>0 and dt<=K.dtMax then updateClock=updateClock+dt end
 local counter=Applier.clock(host)
 if counter and updateCounter and counter>updateCounter then step=math.max(step,counter-updateCounter) end
 updateCounter=counter; updateNow=updateNow+math.min(step,1); host.updateNow=updateNow
 -- Après la restitution (redémarrage demandé) : seule l'alerte de redémarrage en retard reste suivie.
 if released then if updater.phase=='restarting' then Update.tick(updater,port,false,updateNow); updateLog() end; return end
 local player=frame.player>0 and frame.cars[frame.player] or nil
 host.updateStopped=Update.stopped(frame,player)
 Update.tick(updater,port,host.updateStopped,updateNow)
 if not updateAsked and globals.updateCheck and updateClock>=K.updateDelay and updater.phase=='idle' then updateAsked=true; Update.check(updater,port,updateNow) end
 local pit=player~=nil and player.pit==true and not frame.paused
 local panelState=engine.panel
 if pit and not updateNoticed and Update.offered(updater) then
  updateNoticed=true; panelState.updateUntil=engine.time+K.updateNotice; panelState.updateVersion=updater.release.version
 elseif not pit then panelState.updateUntil=-math.huge end
 updateLog()
end
local function protect(fn,arg)
 local ok,err=pcall(fn,arg)
 if not ok then
  engine.errors=engine.errors+1; engine.panic=true
  U.log(engine.log,engine.time,'ERROR',tostring(err):sub(1,256),-1)
  pcall(stop)
 end
 return ok
end
-- Démarrage surveillé (mise à jour) : la version installée est confirmée après K.bootFrames images où le moteur a tourné
-- sans erreur et K.bootUIFrames dessins sans erreur protégée de la fenêtre ou de l'overlay (Beta 1.36 : une interface en
-- échec à chaque image n'est jamais confirmée ; la version est défaite au lancement suivant).
local booted=false
local bootEngine,bootUI=0,0
if port.unreadable then U.log(engine.log,0,'ERROR','mise a jour: module illisible, app chargee sans mise a jour ('..port.unreadable..')',-1) end
HUMANAI={engine=engine,host=host,release=release,updater=updater,port=port,panel=panel}
-- Pont vers les apps compagnes (Beta 1.46) : seulement si SpotterEnginer est installé (dossier apps/lua/SpotterEnginer et
-- son manifest.ini, lus une fois au lancement), l'état du moteur est recopié à chaque image dans une structure partagée
-- (ac.connect), après update(), même moteur arrêté (pause, replay, en ligne, app coupée : la raison est publiée). Sans
-- lui : rien n'est ouvert ni calculé, une ligne au journal. Lecture seule du moteur ; une erreur coupe le pont seul (une
-- ligne au journal), jamais le moteur ni l'interface.
if Applier.companionInstalled(companion) then
 local why
 bridge=Bridge.new(Config.release)
 bridgePort,why=Applier.bridgeOpen(Bridge.layout)
 U.log(engine.log,0,'INFO',bridgePort and string.format('pont des apps compagnes: ouvert (version %d)',Bridge.layout.version) or 'pont des apps compagnes: indisponible ('..tostring(why)..')',-1)
else
 U.log(engine.log,0,'INFO','pont des apps compagnes: '..companion..' absent, pont inactif',-1)
end
-- Une seule fonction pour l'appel protégé : rien n'est créé à chaque image.
local function bridgeWork() Bridge.beat(bridge,bridgePort.hello); Bridge.publish(bridge,bridgePort.data,engine,frame) end
local function bridgeStep()
 if released or not bridgePort then return end
 local ok,err=pcall(bridgeWork)
 if not ok then
  pcall(Bridge.close,bridge,bridgePort.hello); bridgePort=nil
  U.log(engine.log,engine.time or 0,'ERROR','pont des apps compagnes coupe: '..tostring(err):sub(1,200),-1)
 end
end
-- Tests : port du pont (nil sans app lectrice, ou après une erreur ou le déchargement).
HUMANAI.bridgePort=function() return bridgePort end
function script.HUMANAI__UPDATE(dt)
 local before=Applier.clock(host)
 local ran=protect(update,dt)
 if ran and not booted then
  bootEngine=bootEngine+1
  -- Démarrage confirmé : surveillance levée, puis restes de la mise à jour effacés (Beta 1.37).
  if bootEngine>=K.bootFrames and bootUI>=K.bootUIFrames then booted=true; bootWatched=false; pcall(port.bootOk); if port.ready then pcall(Update.tidy,updater,port); updateLog() end end
 end
 local ok,err=pcall(updateTick,dt)
 if not ok then host.errors=host.errors+1; U.log(engine.log,engine.time,'ERROR','mise a jour: '..tostring(err):sub(1,200),-1) end
 -- Options de CSP (Beta 1.40) : une erreur les fige jusqu'au prochain lancement (jamais une erreur à chaque image).
 if not released and csp.writable and not bootWatched then
  local okCsp,errCsp=pcall(cspStep,dt)
  if not okCsp then csp.writable=false; host.errors=host.errors+1; U.log(engine.log,engine.time,'ERROR','options CSP: '..tostring(errCsp):sub(1,200),-1) end
 end
 bridgeStep()
 local after=before and Applier.clock(host)
 if after then
  local cost=math.max(0,after-before)*1000
  engine.maxFrame=math.max(engine.maxFrame,cost)
  engine.meanFrame=engine.meanFrame+(cost-engine.meanFrame)/math.max(1,math.min(engine.frames,K.performanceWindow))
 end
end
-- Un seul point d'entrée par image, actif aussi lorsque le setup est ouvert.
function script.update(dt) script.HUMANAI__UPDATE(dt) end
function script.HUMANAI__MENU() if not released then Applier.menu(host,Snapshot.menu()) end end
-- Fenêtres de réglage : une erreur d'affichage est journalisée (une fois par message) sans arrêter le moteur.
local lastUIError=''
local function protectUI(fn,arg)
 local ok,err=pcall(fn,arg)
 if ok then
  if not booted then bootUI=bootUI+1 end
 else
  host.errors=host.errors+1
  local text=tostring(err):sub(1,200)
  if text~=lastUIError then lastUIError=text; U.log(engine.log,engine.time,'ERROR','ui:'..text,-1) end
 end
end
-- Image lente d'une fenêtre (Beta 1.39) : au-delà de K.uiSlowFrame s, un WARN par lieu (onglet, section ; overlay), au
-- plus K.uiSlowLogs, pour situer un gel dans le journal de la séance suivante. Première image de chaque fenêtre (polices
-- chargées) : seuil K.uiSlowFirst.
local slowSeen,slowCount,slowWarm={},0,{}
local function timedUI(fn,place)
 local started=Applier.clock(host)
 protectUI(fn,panel)
 local ended=started and Applier.clock(host)
 local spent=ended and ended-started or 0
 local window=place or 'main'
 local limit=slowWarm[window] and K.uiSlowFrame or K.uiSlowFirst; slowWarm[window]=true
 if spent>limit and slowCount<K.uiSlowLogs then
  local where=place or UI.where(panel)
  if not slowSeen[where] then
   slowSeen[where]=true; slowCount=slowCount+1
   U.log(engine.log,engine.time,'WARN',string.format('interface lente: %s, %.0f ms',where,spent*1000),-1)
  end
 end
end
function script.HUMANAI__MAIN()
 script.HUMANAI__MENU()
 if host.menuVisible then
  -- Une seule fois : fenêtre ramenée à la taille compacte (Beta 1.14), puis la taille du pilote est respectée.
  if not globals.windowCompacted and Applier.compactWindow(host,UI.compactSize()) then globals.windowCompacted=true; dirty() end
  timedUI(UI.main)
 end
end
-- Panneau de drapeaux : protégé comme les autres fenêtres ; une erreur d'affichage est journalisée une fois et
-- n'arrête jamais le moteur.
-- Panneau de drapeaux dans une fenêtre : absent du manifeste (seul IN_GAME est déclaré, l'overlay le remplace) ; gardé
-- pour les tests et les anciens points d'appel, il dessine le même contenu que l'overlay.
function script.HUMANAI__FLAGS() if not released then protectUI(UI.flags,panel) end end
-- Overlay en jeu (Beta 1.25, rappel IN_GAME) : fenêtre transparente dessinée par l'app, comme SuperHUD.
function script.HUMANAI__HUD()
 if released then return end
 timedUI(UI.hud,'overlay')
 pcall(messages,globals.overlayMessages and globals.overlayBlockMessages and globals.enabled,globals.overlayMessages and globals.enabled and Cspgui.applied(csp,'HIDE_SYSTEM_MESSAGES'))
end
