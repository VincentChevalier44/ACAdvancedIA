local ffi=require('ffi')
local U=require('src/util')
local C=require('src/config')
local Caps=require('src/caps')
local Perception=require('src/perception')
local Presets=require('src/presets')
local K=C.K
local M={}
local setters={level='setAILevel',aggression='setAIAggression',caution='setAICaution',offset='setAISplineOffset',grip='setExtraAIGrip',speed='setAITopSpeed',rain='setAIRainTyres',tyres='setAITyres',pit='setAIPitStopRequest',
 stop='setAIStopCounter',flag='overrideRacingFlag',park='setAINoInput',teleport='teleportCarTo',penalty='setCarPenalty',drs='allowCarDRS',drsActive='setCarDRS',brakeMistake='setAIBrakeMistake',tractionMistake='setAITractionMistake',fuel='overrideAIRequestedFuel',startDelay='setAITimeToStart',awake='awakeCar',position='setCarPosition',velocity='setCarVelocity',repairBody='setCarBodyDamage',repairSuspension='setSuspensionDamage',repairEngine='setCarEngineLife',fuelSet='setCarFuel'}
local windowIDs={'main'}
-- Événements de l'applicateur vers le journal du moteur (relié par le fichier d'entrée).
local function note(a,level,text,index) if a.note then a.note(level,text,index) end end
-- Résultat mémorisé par fonction cdata (son type ne change jamais) : ni texte du type ni motif à chaque appel.
local callableCdata=setmetatable({},{__mode='k'})
local function callable(f)
 if type(f)=='function' then return true end
 if type(f)~='cdata' or f==nil then return false end
 local known=callableCdata[f]
 if known==nil then local name=tostring(ffi.typeof(f)); known=not name:find('[',1,true) and name:match('%b()%s*>$')~=nil; callableCdata[f]=known end
 return known
end
M.callable=callable
local function initClock()
 -- Compteur Windows en lecture seule, sans chargement de DLL et sans os.*.
 pcall(ffi.cdef,'int QueryPerformanceCounter(int64_t*); int QueryPerformanceFrequency(int64_t*);')
 local counter,frequency=ffi.C.QueryPerformanceCounter,ffi.C.QueryPerformanceFrequency
 local buffer=ffi.new('int64_t[1]')
 if frequency(buffer)==0 or tonumber(buffer[0])<=0 then return nil end
 return {counter=counter,buffer=buffer,frequency=tonumber(buffer[0]),failures=0}
end
local function present(name)
 local controls=name=='brake' or name=='flash'
 return controls and callable(ac.overrideCarControls) or not controls and physics~=nil and callable(physics[setters[name]])
end
-- Seul le frein est imposé : les autres champs reçoivent la valeur neutre documentée par le SDK
-- (direction et pédales d'origine, rapport, mode MGU-H et KERS conservés), quelle que soit leur valeur initiale.
local function setBrake(controls,value)
 controls.combineAxis=true; controls.steer=math.huge; controls.gas=0; controls.handbrake=0; controls.clutch=1; controls.requestedGearIndex=0; controls.mguhMode=-1; controls.kers=-1
 controls.brake=value
end
-- Appel de phares d'une IA : mêmes valeurs neutres, frein additionnel en cours conservé, impulsion d'une image.
local function setFlash(controls,brake) setBrake(controls,brake); controls.headlightsFlash=true end
local function write(name,index,value,extra)
 if name=='brake' or name=='flash' then
  local ok,controls=pcall(ac.overrideCarControls,index)
  if not ok or not controls then return false end
  return pcall(name=='flash' and setFlash or setBrake,controls,value)
 end
 local f=physics and physics[setters[name]]
 if not callable(f) then return false end
 if name=='flag' then return pcall(f,value) end -- Drapeau du joueur : sans indice de voiture.
 -- Pénalité du joueur : coupure des gaz pendant value secondes, sans indice de voiture.
 if name=='penalty' then return pcall(f,extra or ac.PenaltyType and ac.PenaltyType.SlowDown or K.penaltySlowDown,value) end
 if name=='offset' then return pcall(f,index,value,extra) end
 if name=='position' then return pcall(f,index,value,extra) end -- position, puis direction
 if name=='tractionMistake' then return pcall(f,index,value,extra) end -- durée, puis sévérité (multiplicateur des gaz)
 if name=='fuel' then return pcall(f,index,value,extra) end -- litres demandés, puis tours avant un arrêt natif
 -- Réparations (Beta 1.20) : carrosserie à value sur ses quatre côtés ; suspensions des quatre roues (défaut du SDK).
 if name=='repairBody' then return pcall(function() return f(index,vec4(value,value,value,value)) end) end
 if name=='repairSuspension' then return pcall(f,index,nil,value) end
 return pcall(f,index,value)
end
function M.new()
 local a={cars={},allowed=false,errors=0,rejected=0,stores={},dirtyAt=0,dirty=false,lastSave=-math.huge,recoveryDirty=false,storageErrors=0,
  port={present=present,write=write},releaseToken=nil,sessionToken=nil,safety={left=false,right=false,nearest=0},offsetSign=0,aiFunctions={},presets={},presetStores={},menuVisible=false,menuLast=nil,
  flagOverride=false}
 for i=1,K.maxCars do a.cars[i]={owned=false,reset=false,level=nil,aggression=nil,caution=nil,offset=0,brake=0,grip=nil,
  originalLevel=1,originalAggression=0.5,lastWrite=-math.huge,id='',readAt=0,speed=nil,offsetReset=true,rainHint=nil,originalRain=false,pitRequest=false,weatherAt=-math.huge,tyreAt=-math.huge,
  levelAt=-math.huge,recovered=false,drsBlocked=false,drsAt=-math.huge,stop=false,stopAt=-math.huge,flashEvent=0,flashPulses=0,flashAt=-math.huge,pitAt=-math.huge,tyreVisit=-1,repairVisit=-1,teleportAt=-math.huge,startDelayFor='',placeFor='',placeAt=-math.huge,launchPending=false,launchAt=-math.huge,fuelRequested=-1,fuelSetFor='',fuelBoxed=false,fuelBefore=-1,parked=false,parkAt=-math.huge,teleported=false,redTeleported=false} end
 a.caps=Caps.new(a.port); a.clipboard=M.clipboard
 local ok,timer=pcall(initClock); if ok then a.timer=timer end
 pcall(function()
  if type(physics)=='table' then
   for name,f in pairs(physics) do
    if type(name)=='string' and name:find('AI',1,true) and callable(f) and #a.aiFunctions<K.maxCapabilities then a.aiFunctions[#a.aiFunctions+1]=name end
   end
   table.sort(a.aiFunctions)
  end
 end)
 return a
end
function M.clock(a)
 local timer=a.timer
 if not timer then return nil end
 local ok,result=pcall(timer.counter,timer.buffer)
 if not ok or result==0 then
  timer.failures=timer.failures+1; if timer.failures>=K.capabilityFailures then a.timer=nil end
  return nil
 end
 timer.failures=0; return tonumber(timer.buffer[0])/timer.frequency
end
function M.access(a)
 a.allowed=false
 if not physics or not callable(physics.allowed) then return false end
 local ok,allowed=pcall(physics.allowed); a.allowed=ok and allowed==true
 if not ok then a.errors=a.errors+1 end
 return a.allowed
end
function M.openStore(a)
 local layout={}; for k,v in pairs(C.globalDefaults) do layout[k]=v end
 local ok,store=pcall(ac.storage,layout,'humanai:g:'); if ok then a.stores.g=store end
 local valid,g,errors=pcall(C.validateGlobals,ok and store or C.globalDefaults)
 if not valid then g=C.validateGlobals(C.globalDefaults); errors=1 end
 a.storageErrors=errors+(ok and 0 or 1)
 local profiles={}
 for _,p in ipairs(C.profiles) do
  local defaults=C.defaults(p); local good,s=pcall(ac.storage,defaults,'humanai:p:'..p..':')
  if good then a.stores[p]=s end
  local accepted,normalized,n=pcall(C.validate,p,good and s or defaults)
  profiles[p]=accepted and normalized or defaults
  a.storageErrors=a.storageErrors+(accepted and n or 1)+(good and 0 or 1)
 end
 -- Données 1.2.0 : migration unique, sauvegardée à la première occasion.
 local migrated,upgraded,fresh,restored=pcall(C.migrate,g,profiles)
 if migrated and upgraded then a.upgraded=upgraded; a.firstInstall=fresh==true; a.signsRestored=restored==true; a.dirty=true; a.dirtyAt=0 end
 for i=1,K.maxPresets do
  local opened,slot=pcall(ac.storage,Presets.layout(),'humanai:custom:'..i..':')
  if opened then
   a.presetStores[i]=slot
   local good,entry,errors=pcall(Presets.decode,slot)
   if good then a.presets[i]=entry; if entry and errors>0 then a.storageErrors=a.storageErrors+errors end end
  end
 end
 return g,profiles
end
function M.savePreset(a,entry)
 local at
 for i=1,K.maxPresets do if a.presets[i] and a.presets[i].name==entry.name then at=i; break end end
 if not at then for i=1,K.maxPresets do if not a.presets[i] then at=i; break end end end
 if not at or not a.presetStores[at] then return false end
 local values=Presets.encode(entry)
 local ok=pcall(function()
  a.presetStores[at].name=''
  for key,value in pairs(values) do if key~='name' then a.presetStores[at][key]=value end end
  a.presetStores[at].name=entry.name
 end)
 if ok then a.presets[at]=entry end
 return ok
end
function M.deletePreset(a,index)
 if not U.finite(index) or index%1~=0 or index<1 or index>K.maxPresets or not a.presets[index] or not a.presetStores[index] then return false end
 local ok=pcall(function() a.presetStores[index].name='' end)
 if ok then a.presets[index]=nil end
 return ok
end
-- Option CSP « Hide race flags » (gui.ini, [HIDE] HIDE_RACE_FLAGS) : true ou false, nil si illisible.
local function readRaceFlagsHidden()
 return ac.INIConfig.cspModule(ac.CSPModuleID.GUI):get('HIDE','HIDE_RACE_FLAGS',false)
end
function M.menu(a,visible)
 a.menuVisible=visible
 if visible~=a.menuLast then
  a.menuLast=visible
  -- Relue à chaque ouverture du menu (réglage CSP modifiable en cours de partie).
  if visible then
   local ok,value=pcall(readRaceFlagsHidden)
   if ok and type(value)=='boolean' then a.raceFlagsHidden=value elseif ok and type(value)=='number' then a.raceFlagsHidden=value~=0 else a.raceFlagsHidden=nil end
  end
  if callable(ac.setWindowOpen) then pcall(ac.setWindowOpen,'main',visible) end
 end
 if not visible and callable(ac.isWindowOpen) and callable(ac.setWindowOpen) then
  for _,id in ipairs(windowIDs) do local ok,opened=pcall(ac.isWindowOpen,id); if ok and opened then pcall(ac.setWindowOpen,id,false) end end
 end
end
-- Beta 1.14 : fenêtre de réglages ramenée une fois à la taille compacte (target) si elle est plus large. Renvoie true
-- quand c'est fait ou impossible (fonction ou fenêtre absente : noté au journal), pour ne jamais réessayer.
function M.compactWindow(a,target)
 if not callable(ac.accessAppWindow) then return true end
 local ok,w=pcall(ac.accessAppWindow,'IMGUI_LUA_ACAdvancedIA_main')
 if not ok or not w then note(a,'WARN','fenetre de reglages introuvable: taille laissee telle quelle',-1); return true end
 local good,size=pcall(function() return w:size() end)
 if good and size and size.x>target.x+1 then
  local done=pcall(function() w:resize(target) end)
  note(a,'INFO',string.format('fenetre de reglages %s: %.0f x %.0f -> %.0f x %.0f',done and 'compactee' or 'non compactee',size.x,size.y,target.x,target.y),-1)
 end
 return true
end
function M.baselines(a,frame)
 for i=1,frame.count do
  local car,s=frame.cars[i],a.cars[i]; local known=s.owned and s.id==(car.identity or car.id)
  car.baseLevel=known and s.originalLevel or car.aiLevel; car.baseAggression=known and s.originalAggression or car.aiAggression
 end
end
function M.dirty(a,now) a.dirtyAt=now+K.saveDelay; a.dirty=true end
function M.rebase(a,amount)
 if a.dirty then a.dirtyAt=a.dirtyAt-amount end
 a.lastSave=a.lastSave-amount
 a.caps.probeAt=a.caps.probeAt-amount
 for i=1,K.maxCars do
  local s=a.cars[i]; s.lastWrite=s.lastWrite-amount; s.readAt=s.readAt-amount; s.weatherAt=s.weatherAt-amount; s.tyreAt=s.tyreAt-amount; s.levelAt=s.levelAt-amount
  s.pitAt=s.pitAt-amount; s.stopAt=s.stopAt-amount; s.parkAt=s.parkAt-amount; s.teleportAt=s.teleportAt-amount; s.flashAt=s.flashAt-amount; s.drsAt=s.drsAt-amount
 end
end
function M.save(a,g,profiles,now,replay,force)
 if replay or not a.dirty or not force and (now<a.dirtyAt or now-a.lastSave<K.saveDelay) then return end
 local valid=C.validateGlobals(g)
 local ok=pcall(function()
  if a.stores.g then for k in pairs(C.globalDefaults) do a.stores.g[k]=valid[k] end end
  for _,p in ipairs(C.profiles) do
   local v=C.validate(p,profiles[p]); local store=a.stores[p]
   if store then for k in pairs(v) do store[k]=v[k] end end
  end
 end)
 if ok then a.lastSave=now; a.dirtyAt=0; a.dirty=false else a.errors=math.min(K.counterMax,a.errors+1) end
end
-- final : déchargement de l'app, sans image suivante. Restitution aussi en pause, en replay, aux stands et hors piste ;
-- seul l'offset reste soumis à la piste et à l'occupation, jamais d'après des positions de replay.
-- Stratégie pluie native rendue à son état d'origine.
local function restoreRain(a,s,car)
 if s.rainHint~=nil and Caps.restoreCall(a.caps,'rain',car.index,s.originalRain) then s.rainHint=nil; a.recoveryDirty=true end
end
-- Livrée d'origine rendue à une voiture habillée en voiture de sécurité (elle ne l'est plus, ou l'app se décharge).
local function restoreSkin(s,car)
 if not s.skinOriginal then return end
 local original=s.skinOriginal; s.skinOriginal=nil; s.skinApplied=nil
 if car.valid and callable(ac.findNodes) and callable(ac.getFolder) then
  pcall(function() ac.findNodes('carRoot:'..car.index):applySkin(ac.getFolder(ac.FolderID.ContentCars)..'/'..car.id..'/skins/'..original) end)
 end
end
-- keepParked : fin de session, les voitures garées restent garées (rendues à la session suivante ou au déchargement).
function M.restore(a,frame,pendingOnly,now,final,keepParked)
 if not a.allowed or frame.online or not final and (frame.replay or frame.paused) then for i=1,K.maxCars do if a.cars[i].owned then a.cars[i].reset=true end end; return end
 if not pendingOnly and a.flagOverride and Caps.restoreCall(a.caps,'flag',-1,K.flagNone) then a.flagOverride=false; a.recoveryDirty=true end
 if final then M.releaseBlackFlag(a) end
 if not pendingOnly then M.releaseDrs(a,frame) end
 for i=1,frame.count do
  local car=frame.cars[i]; local s=a.cars[i]
  if final then restoreSkin(s,car) end
  -- Attente de sortie des stands en cours (essais, qualifications) : annulée à la restitution, l'IA part aussitôt.
  if not pendingOnly and s.startDelayFor~='' then
   if car.valid and car.control and not car.player and car.inPitBox then Caps.restoreCall(a.caps,'startDelay',car.index,0) end
   s.startDelayFor=''
  end
  if s.owned and (not pendingOnly or s.reset) then
   s.reset=true
   if car.valid and s.id~=(car.identity or car.id) then s.owned=false; s.reset=false; s.offset=0; s.recovered=false; a.recoveryDirty=true end
   local mine=s.owned and car.valid and car.control and not car.player and (car.identity or car.id)==s.id
   if mine and s.stop and Caps.restoreCall(a.caps,'stop',car.index,0) then s.stop=false; a.recoveryDirty=true end
   if mine and s.parked and not keepParked and Caps.restoreCall(a.caps,'park',car.index,false) then s.parked=false; s.parkAt=-math.huge; a.recoveryDirty=true end
   -- Frein additionnel relâché aussi hors conduite (stands, hors piste) : seule écriture de frein admise aux stands.
   if mine and s.brake~=0 and Caps.restoreCall(a.caps,'brake',car.index,0) then s.brake=0; a.recoveryDirty=true end
   if mine and (final or not car.offtrack) then
    restoreRain(a,s,car)
    -- Dans la voie des stands, l'annulation attend la sortie : false bloquerait l'arrêt en cours (SDK).
    if s.pitRequest and (final or not car.pit) and Caps.restoreCall(a.caps,'pit',car.index,false) then s.pitRequest=false; a.recoveryDirty=true end
   end
   -- Demande de carburant rendue à AC (math.huge : plus de remplacement).
   if mine and s.fuelRequested>=0 and Caps.restoreCall(a.caps,'fuel',car.index,math.huge) then s.fuelRequested=-1; a.recoveryDirty=true end
   local driving=mine and not car.pit and not car.offtrack
   if driving or final and mine then
    local good=s.offsetReset==true and s.offset==0
    if not good and driving and not frame.replay then
     Perception.occupancy(frame.cars,frame.count,i,a.g or C.globalDefaults,a.safety)
     local canonical=s.offset*(a.offsetSign==0 and 1 or a.offsetSign)
     local safe=not (canonical>0 and a.safety.left or canonical<0 and a.safety.right)
     if a.offsetSign==0 then safe=not a.safety.left and not a.safety.right end
     if safe then good=Caps.restoreCall(a.caps,'offset',car.index,0,false); s.offsetReset=good end
    end
    if s.level~=nil then if Caps.restoreCall(a.caps,'level',car.index,s.originalLevel) then s.level=nil else good=false end end
    if s.aggression~=nil then if Caps.restoreCall(a.caps,'aggression',car.index,s.originalAggression) then s.aggression=nil else good=false end end
    if s.caution~=nil then if Caps.restoreCall(a.caps,'caution',car.index,K.defaultCaution) then s.caution=nil else good=false end end
    if s.grip~=nil then if Caps.restoreCall(a.caps,'grip',car.index,K.gripBase) then s.grip=nil else good=false end end
    if s.brake~=0 then good=false end
    if s.speed~=nil then if Caps.restoreCall(a.caps,'speed',car.index,K.unlimitedSpeed) then s.speed=nil else good=false end end
    if s.rainHint~=nil or s.pitRequest or s.stop or s.parked or s.fuelRequested>=0 then good=false end
    if good then s.owned=false; s.reset=false; s.offset=0; s.level=nil; s.aggression=nil; s.caution=nil; s.grip=nil; s.brake=0; s.speed=nil; s.recovered=false; s.restoredAt=now; s.justRestored=true; a.recoveryDirty=true end
   end
  end
 end
end
local function send(a,s,name,index,value,epsilon)
 if not U.finite(value) then a.rejected=a.rejected+1; return false end
 local old=s[name]
 if old==nil or math.abs(value-old)>=epsilon then
  if Caps.call(a.caps,name,index,value) then if old==nil then a.recoveryDirty=true end; s[name]=value; return true end
 end
 return false
end
local function field(a,s,name,index,owned,value,epsilon,original)
 if owned~=false then
  if a.caps[name].available then send(a,s,name,index,value,epsilon) end
 elseif s[name]~=nil and Caps.restoreCall(a.caps,name,index,original) then s[name]=nil; a.recoveryDirty=true end
end
local function claim(a,s,car,now)
 if s.owned and s.id==(car.identity or car.id) then return end
 s.id=car.identity or car.id
 if s.restoredAt~=now then s.originalLevel=car.aiLevel; s.originalAggression=car.aiAggression end
 s.owned=true; s.recovered=false; a.recoveryDirty=true
 s.offset=0; s.level=nil; s.aggression=nil; s.caution=nil; s.brake=0; s.grip=nil; s.speed=nil; s.offsetReset=true
 s.rainHint=nil; if s.restoredAt~=now then s.originalRain=car.nativeRainTyres==true end; s.pitRequest=false; s.weatherAt=-math.huge; s.tyreAt=-math.huge; s.stop=false; s.stopAt=-math.huge
 s.pitAt=-math.huge; s.tyreVisit=-1
end
local function weather(a,s,car,cmd,now)
 if not car.valid or not car.control or car.player or car.offtrack then return end
 if cmd.weatherManaged and (not s.reset or car.pit) then
  claim(a,s,car,now)
  -- Tant que l'état natif correspond déjà à la décision, la stratégie pluie de CSP n'est pas forcée.
  local native=car.nativeRainTyresKnown and s.rainHint==nil and car.nativeRainTyres==cmd.weatherRain
  if a.caps.rain.available and s.rainHint~=cmd.weatherRain and not native and Caps.call(a.caps,'rain',car.index,cmd.weatherRain) then s.rainHint=cmd.weatherRain; a.recoveryDirty=true end
  -- Gomme inadaptée dans la voie des stands : changée aussitôt, même en roulant (les IA apparaissent souvent aux stands
  -- en intermédiaires sur piste sèche et repartent avant le contrôle suivant).
  local lane=car.pit and cmd.weatherCompound>=0 and car.compoundIndex~=cmd.weatherCompound
  if now>=s.weatherAt or lane then
   s.weatherAt=now+K.weatherPeriod
   if cmd.weatherCompound>=0 and (car.pit or cmd.weatherGrid and car.kmh<=K.tyreStopSpeed) and car.compoundIndex~=cmd.weatherCompound and now>=s.tyreAt and a.caps.tyres.available then
    local before=car.compoundIndex
    if Caps.call(a.caps,'tyres',car.index,cmd.weatherCompound) then
     s.tyreAt=now+5
     local names=car.tyreNames or {}
     note(a,'INFO',string.format('pneus adaptes a la meteo %s: %s -> %s (%s)',car.inPitBox and 'aux stands' or car.pit and 'dans la voie des stands' or 'a l arret au depart',
      tostring(names[before] or before),tostring(names[cmd.weatherCompound] or cmd.weatherCompound),cmd.weatherRain and 'pluie' or 'sec'),car.index+1)
    end
   end
  end
 elseif s.owned and s.id==(car.identity or car.id) then
  restoreRain(a,s,car)
 end
end
-- Nom d'une gomme pour le journal : nom court et nom long (Beta 1.24).
local function tyreLabel(car,index)
 if index==nil then return '?' end
 return ((car.tyreNames and car.tyreNames[index]) or '?')..((car.tyreLongNames and car.tyreLongNames[index]) and ' '..car.tyreLongNames[index] or '')
end
-- Demande de passage aux stands, seul arbitre de la météo et des règles. Elle reste active dans la voie des stands
-- jusqu'à l'arrêt ; false n'est envoyé que pour une demande de l'app, car il bloquerait aussi un arrêt natif (SDK).
local function pitRequest(a,s,car,cmd,now)
 if not car.valid or not car.control or car.player or car.offtrack then return end
 local managed=(cmd.weatherManaged or cmd.rulePit) and (not s.reset or car.pit)
 if managed then
  claim(a,s,car,now)
  if now>=s.pitAt then
   s.pitAt=now+K.weatherPeriod
   if (cmd.weatherManaged and cmd.weatherPit or cmd.rulePit) and a.caps.pit.available then
    if not car.pit and Caps.call(a.caps,'pit',car.index,true) then s.pitRequest=true; a.recoveryDirty=true end
   elseif s.pitRequest and not car.pit and Caps.restoreCall(a.caps,'pit',car.index,false) then s.pitRequest=false; a.recoveryDirty=true end
  end
 elseif s.pitRequest and s.owned and s.id==(car.identity or car.id) and not car.pit and Caps.restoreCall(a.caps,'pit',car.index,false) then s.pitRequest=false; a.recoveryDirty=true end
 -- Arrêt réglementaire : un train de pneus par passage à l'emplacement. Une autre voiture dans l'emplacement de la
 -- liste (changement de pilote ou de voiture) repart de zéro.
 if s.tyreVisit>=0 and s.id~=(car.identity or car.id) then s.tyreVisit=-1 end
 if cmd.pitCompound>=0 and car.inPitBox and car.kmh<=K.tyreStopSpeed and s.tyreVisit~=cmd.pitVisit and now>=s.tyreAt and a.caps.tyres.available then
  claim(a,s,car,now)
  -- Journal (Beta 1.24) : gomme posée et gomme d'avant, avec leurs noms (variantes d'adhérence d'un même mod).
  if Caps.call(a.caps,'tyres',car.index,cmd.pitCompound) then s.tyreVisit=cmd.pitVisit; s.tyreAt=now+5; note(a,'INFO',string.format('pneus poses: composé %d (%s), avant %s (%s)',cmd.pitCompound,tyreLabel(car,cmd.pitCompound),tostring(car.compoundIndex or '?'),tyreLabel(car,car.compoundIndex)),car.index+1) end
 end
 -- Réparations (Beta 1.20) : une fois par passage à l'emplacement, voiture arrêtée ; seuls les dégâts lus sont réparés.
 if s.repairVisit>=0 and s.id~=(car.identity or car.id) then s.repairVisit=-1 end
 if cmd.pitRepair and car.inPitBox and car.kmh<=K.tyreStopSpeed and s.repairVisit~=cmd.pitVisit then
  claim(a,s,car,now); s.repairVisit=cmd.pitVisit
  local damage,worn,life=car.damageBody or 0,car.damageSuspension or 0,car.engineLife or K.engineLifeNew
  local body=damage>0 and Caps.call(a.caps,'repairBody',car.index,0)
  local suspension=worn>0 and Caps.call(a.caps,'repairSuspension',car.index,0)
  local engine=life<K.engineLifeNew and Caps.call(a.caps,'repairEngine',car.index,K.engineLifeNew)
  -- Journal (Beta 1.23) : seulement si quelque chose a été réparé (sans dégât lu à l'arrêt : déjà réparé par AC).
  if body or suspension or engine then
   note(a,'INFO',string.format('reparations: carrosserie %.0f km/h%s, suspensions %.2f%s, moteur %.0f%s ; reparation AC en cours: %s',damage,body and ' (reparee)' or '',
    worn,suspension and ' (reparees)' or '',life,engine and ' (neuf)' or '',car.repairingNative and 'oui' or 'non'),car.index+1)
  end
 end
 -- Carburant demandé à l'arrêt forcé (écrit avant l'emplacement, au litre près), rendu à AC sans demande de l'app.
 if cmd.fuelTarget>=0 and a.caps.fuel.available then
  local liters=math.floor(cmd.fuelTarget+0.5)
  if liters~=s.fuelRequested and not car.inPitBox then
   claim(a,s,car,now)
   if Caps.call(a.caps,'fuel',car.index,liters,cmd.fuelLaps) then
    s.fuelRequested=liters; a.recoveryDirty=true
    note(a,'INFO',string.format('carburant demande: %d L (%.1f L a bord), %d tour(s) avant un arret natif',liters,car.fuel or -1,cmd.fuelLaps),car.index+1)
   end
  end
 elseif s.fuelRequested>=0 and s.owned and s.id==(car.identity or car.id) and not car.inPitBox and Caps.restoreCall(a.caps,'fuel',car.index,math.huge) then s.fuelRequested=-1; a.recoveryDirty=true end
 -- Plein de course avant le départ (sans ravitaillement prévu) : une fois par voiture et par session.
 local fuelKey=(car.identity or car.id)..'|'..(a.session or 0)
 if cmd.fuelSet>=0 and s.fuelSetFor~=fuelKey and a.caps.fuelSet.available then
  claim(a,s,car,now)
  if Caps.call(a.caps,'fuelSet',car.index,cmd.fuelSet) then s.fuelSetFor=fuelKey; note(a,'INFO',string.format('carburant au depart: %.1f L (%.1f L avant)',cmd.fuelSet,car.fuel or -1),car.index+1) end
 end
 -- Journal : carburant à l'entrée et à la sortie de l'emplacement (sens de la demande vérifié en jeu).
 if car.inPitBox and not s.fuelBoxed then s.fuelBoxed=true; s.fuelBefore=car.fuel or -1
 elseif not car.inPitBox and s.fuelBoxed then
  s.fuelBoxed=false
  if s.fuelRequested>=0 then note(a,'INFO',string.format('carburant: %.1f L avant l arret, %.1f L apres (demande %d L)',s.fuelBefore,car.fuel or -1,s.fuelRequested),car.index+1) end
 end
end
-- Essais et qualifications (Beta 1.22) : attente native d'AC à l'emplacement avant la sortie, écrite une fois par
-- voiture et par tirage ; 0 l'annule (voiture sortie de son emplacement avant son tour), où qu'elle soit.
local function startDelay(a,s,car,cmd)
 local wait=cmd.startDelay or -1
 if wait<0 or s.startDelayFor==cmd.startDelayFor or not car.valid or not car.control or car.player or wait>0 and not car.inPitBox then return end
 s.startDelayFor=cmd.startDelayFor
 if Caps.call(a.caps,'startDelay',car.index,wait) and wait==0 then note(a,'WARN','sortie des stands etalee: attente annulee (voiture sortie de son emplacement)',car.index+1) end
end
-- Répartition sur le circuit (Beta 1.26) : IA posée sur la trajectoire de l'IA à la progression voulue, alignée par CSP
-- sur cette trajectoire (direction absente), attente native d'AC annulée d'abord ; élan de K.spreadSpeed km/h donné
-- ensuite, une fois le saut de position vu, dans l'axe réel de la voiture (jamais de glissade, jamais arrêtée en
-- piste) ; nouvel essai toutes les K.spreadRetry s tant que le moteur la demande (pas encore à sa place).
local function place(a,s,car,cmd,now)
 if s.launchPending and car.valid and (car.teleport or now>=s.launchAt) then
  s.launchPending=false
  if car.teleport and car.kmh<K.spreadSpeed then Caps.call(a.caps,'velocity',car.index,vec3(car.lx,0,car.lz)*(K.spreadSpeed/3.6)) end
 end
 if (cmd.place or -1)<0 or not car.valid or not car.control or car.player then return end
 if s.placeFor==cmd.placeFor and now<s.placeAt then return end
 s.placeFor=cmd.placeFor; s.placeAt=now+K.spreadRetry
 local ok,pos=pcall(ac.trackProgressToWorldCoordinate,cmd.place)
 if not ok or not pos then if not a.placeWarned then a.placeWarned=true; note(a,'WARN','repartition: position sur le circuit indisponible',car.index+1) end return end
 Caps.call(a.caps,'startDelay',car.index,0)
 if Caps.call(a.caps,'position',car.index,pos,nil) then s.launchPending=true; s.launchAt=now+K.spreadLaunchWait
 elseif not a.placeWarned then a.placeWarned=true; note(a,'WARN','repartition: placement des IA indisponible (CSP)',car.index+1) end
end
-- IA accidentée retenue par impulsions courtes du compteur d'arrêt natif : un rechargement ou une coupure
-- la libère d'elle-même ; 0 la relâche dès que la piste derrière est libre.
local function hold(a,s,car,cmd,now)
 if not car.valid or not car.control or car.player then return end
 if cmd.stopHold and not car.pit or cmd.pitHold and car.inPitBox then
  -- Retenue en cours : une restitution en attente (voiture sortie de la conduite, hors piste) est annulée, sinon elle
  -- lèverait l'arrêt à chaque image.
  claim(a,s,car,now); s.reset=false
  if now-s.stopAt>=K.stopPulsePeriod and a.caps.stop.available and Caps.call(a.caps,'stop',car.index,K.stopPulse) then
   if not s.stop then a.recoveryDirty=true end; s.stop=true; s.stopAt=now
  end
 elseif s.stop and Caps.restoreCall(a.caps,'stop',car.index,0) then s.stop=false; s.stopAt=-math.huge; a.recoveryDirty=true end
end
function M.flag(a,frame,wanted)
 if not a.allowed or frame.online or frame.replay or frame.paused then return end
 -- Jamais par-dessus un drapeau natif (bleu, blanc, damier, noir) : seulement sans drapeau ou sur le nôtre.
 if wanted and not a.flagOverride and a.caps.flag.available and (frame.flag==K.flagNone or frame.flag==K.flagCaution) then
  if Caps.call(a.caps,'flag',-1,K.flagCaution) then a.flagOverride=true; a.recoveryDirty=true; note(a,'INFO','drapeau HUD du joueur: jaune',-1) end
 elseif not wanted and a.flagOverride and Caps.restoreCall(a.caps,'flag',-1,K.flagNone) then a.flagOverride=false; a.recoveryDirty=true; note(a,'INFO','drapeau HUD du joueur: rendu a AC',-1) end
end
-- Double appel de phares visible, jamais aux stands ; rien à restituer (impulsions d'une image).
local function flash(a,s,car,cmd,now)
 local event=cmd.flashEvent or 0
 if event~=s.flashEvent then s.flashEvent=event; s.flashPulses=K.aiFlashPulses; s.flashAt=now end
 if s.flashPulses>0 and now>=s.flashAt then
  if car.valid and car.control and not car.player and not car.pit and a.caps.flash.available and Caps.call(a.caps,'flash',car.index,s.brake or 0) then
   s.flashPulses=s.flashPulses-1; s.flashAt=now+K.aiFlashInterval
  else s.flashPulses=0 end
 end
end
-- Voiture de sécurité : ramenée une fois à son stand si elle est en piste, garée sans pilote par impulsions,
-- rendue à l'IA dès qu'elle est libérée.
-- Dossier de la livrée « safety » du modèle (content/cars/<modèle>/skins), cherché une fois par modèle.
local function safetySkin(a,model)
 a.skinFolders=a.skinFolders or {}
 if a.skinFolders[model]==nil then
  a.skinFolders[model]=false
  pcall(function()
   local root=ac.getFolder(ac.FolderID.ContentCars)..'/'..model..'/skins'
   io.scanDir(root,'*',function(name,attributes)
    if not a.skinFolders[model] and type(name)=='string' and attributes~=nil and attributes.isDirectory==true and name:lower():find(K.safetySkinPattern,1,true) then a.skinFolders[model]={path=root..'/'..name,name=name} end
   end)
  end)
 end
 return a.skinFolders[model]
end
local function safety(a,s,car,cmd,now)
 if not car.valid or not car.control or car.player then return end
 -- Voiture de sécurité sans sa livrée (grille tirée au sort) : la livrée « safety » du modèle lui est appliquée, une fois.
 local identity=car.identity or car.id
 if cmd.scSkin and s.skinApplied~=identity and callable(ac.findNodes) then
  s.skinApplied=identity
  local skin=safetySkin(a,car.id)
  if skin then
   local ok=pcall(function() ac.findNodes('carRoot:'..car.index):applySkin(skin.path) end)
   if ok and car.skin~='' then s.skinOriginal=car.skin end
   note(a,ok and 'INFO' or 'WARN',ok and 'voiture de securite: livree '..skin.name..' appliquee' or 'voiture de securite: livree '..skin.name..' non appliquee',car.index+1)
  end
 elseif not cmd.scSkin and s.skinOriginal then restoreSkin(s,car) end
 if cmd.scPark or cmd.scSpeed<K.unlimitedSpeed then claim(a,s,car,now) end
 if cmd.scPark then
  -- Ramenée à son emplacement depuis la piste comme depuis la voie des stands (jamais garée en travers) ; de nouveau si
  -- elle en ressort (Beta 1.22 : garée sans pilote, une IA peut quitter son emplacement, Content Manager la placer en
  -- piste), au plus toutes les K.parkReturnPeriod s.
  if not car.inPitBox and now>=s.teleportAt and a.caps.teleport.available and Caps.call(a.caps,'teleport',car.index,'PIT') then s.teleported=true; s.teleportAt=now+K.parkReturnPeriod; note(a,'INFO',cmd.parkReason=='dq' and 'IA disqualifiee: ramenee a son stand' or cmd.parkReason=='spare' and 'voiture de securite en reserve: ramenee a son stand' or 'voiture de securite: ramenee a son stand',car.index+1) end
  if now>=s.parkAt and a.caps.park.available and Caps.call(a.caps,'park',car.index,true) then
   if not s.parked then a.recoveryDirty=true; note(a,'INFO',cmd.parkReason=='dq' and 'IA disqualifiee: garee jusqu a la fin de la session' or cmd.parkReason=='spare' and 'voiture de securite en reserve: garee sans pilote' or 'voiture de securite: garee sans pilote',car.index+1) end; s.parked=true; s.parkAt=now+K.parkPeriod
  end
 else
  s.teleported=false; s.teleportAt=-math.huge
  if s.parked and Caps.restoreCall(a.caps,'park',car.index,false) then s.parked=false; s.parkAt=-math.huge; a.recoveryDirty=true end
  -- Beta 1.25 : libérée mais encore à son emplacement (en course, elle n'en sortait jamais seule) : réveillée, départ
  -- immédiat, aucun freinage forcé, aucun arrêt demandé, toutes les K.scKickPeriod s tant qu'elle y reste ; sa sortie
  -- est notée.
  if cmd.scRelease and car.inPitBox then
   if now>=(s.scKickAt or -math.huge) then
    s.scKickAt=now+K.scKickPeriod
    if not s.scReleasedAt then s.scReleasedAt=now; Caps.call(a.caps,'pit',car.index,false) end
    Caps.call(a.caps,'awake',car.index); Caps.call(a.caps,'startDelay',car.index,0); Caps.call(a.caps,'stop',car.index,0)
   end
  elseif cmd.scRelease and s.scReleasedAt then
   note(a,'INFO',string.format('voiture de securite: sortie de son stand apres %.1f s',now-s.scReleasedAt),car.index+1); s.scReleasedAt=nil
  elseif not cmd.scRelease then s.scReleasedAt=nil; s.scKickAt=-math.huge end
 end
 -- Aucune commande dans la voie des stands (règle D12) : le limiteur natif s'y applique déjà.
 -- Garée, sa limite reste posée (sans effet à l'arrêt) jusqu'à la restitution générale.
 if cmd.scSpeed<K.unlimitedSpeed and not car.pit then send(a,s,'speed',car.index,cmd.scSpeed,K.levelEpsilon) end
end
-- Dépannage : une IA immobile en piste est ramenée une seule fois jusqu'à son stand (jamais le joueur).
local function recover(a,s,car,cmd)
 if not cmd.recover then s.redTeleported=false; return end
 if car.valid and car.control and not car.player and not car.pit and not s.redTeleported and a.caps.teleport.available then
  if Caps.call(a.caps,'teleport',car.index,'PIT') then
   s.redTeleported=true; note(a,'INFO',string.format('IA immobile depannee a son stand (%s, immobile depuis %.0f s)',cmd.recoverReason or '?',cmd.recoverStill or 0),car.index+1)
  end
 end
end
-- Drapeau noir du joueur levé (déchargement, désactivation, nouvelle session) ; jamais pendant une simple pause des
-- commandes (recalibration, sécurité).
function M.releaseBlackFlag(a)
 if a.blackFlag and Caps.restoreCall(a.caps,'penalty',-1,0,ac.PenaltyType and ac.PenaltyType.ReleaseBlackFlag or K.penaltyReleaseBlackFlag) then
  a.blackFlag=false; note(a,'INFO','drapeau noir leve',-1)
 end
end
-- Pénalité du joueur décidée par le moteur : écrite une seule fois par décision ; une écriture refusée est retentée à
-- l'image suivante tant que la capacité reste disponible (trois échecs la désactivent).
function M.penalty(a,frame,t)
 if t.requestId==(a.penaltyServed or 0) then return end
 if not a.allowed or frame.online or frame.replay or frame.paused or frame.player==0 then return end
 local written
 if t.kind=='dq' then
  written=Caps.call(a.caps,'penalty',-1,-1,ac.PenaltyType and ac.PenaltyType.BlackFlag or K.penaltyBlackFlag)
  if written then a.blackFlag=true; note(a,'INFO','drapeau noir applique',frame.player) end
 else
  written=Caps.call(a.caps,'penalty',-1,t.seconds)
  if written then note(a,'INFO',string.format('penalite appliquee: coupure des gaz %.0f s',t.seconds),frame.player) end
 end
 if written or not a.caps.penalty.available then a.penaltyServed=t.requestId end
end
-- Bip « DRS disponible » : fichier son de l'app, joué sans effet 3D ; un événement par bip, le précédent libéré.
local function disposeBeep(a) if a.beepEvent then pcall(function() a.beepEvent:dispose() end); a.beepEvent=nil end end
function M.beep(a,frame,d)
 if d.beepId==(a.beepServed or 0) then return end
 a.beepServed=d.beepId
 if frame.online or frame.replay or frame.paused or not ac.AudioEvent or not callable(ac.dirname) then return end
 disposeBeep(a)
 local ok,event=pcall(ac.AudioEvent.fromFile,{filename=ac.dirname()..'/'..K.drsBeepFile,use3D=false,loop=false},false)
 -- Même niveau quelle que soit la caméra (CSP réduit par défaut à 25 % un son d'app entendu depuis le cockpit), sur le
 -- canal principal : seul le volume général du jeu s'applique.
 local function play()
  event.cameraInteriorMultiplier=1; event.cameraExteriorMultiplier=1; event.cameraTrackMultiplier=1; event.volume=d.volume or 1
  if event.setVolumeChannel and ac.AudioChannel then event:setVolumeChannel(ac.AudioChannel.Main) end
  event:start()
 end
 if ok and event and pcall(play) then a.beepEvent=event
 else
  if ok and event then a.beepEvent=event; disposeBeep(a) end
  if not a.beepFailed then a.beepFailed=true; note(a,'WARN','bip DRS: son indisponible',-1) end
 end
end
-- Bips du temps delta : fichier son de l'app, un seul événement créé une fois et relancé à chaque bip (jusqu'à
-- plusieurs par seconde), même niveau quelle que soit la caméra, canal principal.
function M.deltaBeep(a,frame,d)
 if d.beepId==(a.deltaServed or 0) then return end
 a.deltaServed=d.beepId
 if frame.online or frame.replay or frame.paused or a.deltaFailed or not ac.AudioEvent or not callable(ac.dirname) then return end
 if not a.deltaEvent then
  local ok,event=pcall(ac.AudioEvent.fromFile,{filename=ac.dirname()..'/'..K.deltaBeepFile,use3D=false,loop=false},false)
  if ok and event then a.deltaEvent=event
   pcall(function() if event.setVolumeChannel and ac.AudioChannel then event:setVolumeChannel(ac.AudioChannel.Main) end end)
  else a.deltaFailed=true; note(a,'WARN','bip delta: son indisponible',-1); return end
 end
 local event=a.deltaEvent
 local function play()
  event.cameraInteriorMultiplier=1; event.cameraExteriorMultiplier=1; event.cameraTrackMultiplier=1; event.volume=d.volume or 1
  if event.stop then event:stop() end
  event:start()
 end
 if not pcall(play) then a.deltaFailed=true; pcall(function() event:dispose() end); a.deltaEvent=nil; note(a,'WARN','bip delta: son indisponible',-1) end
end
-- DRS coupé par les règles de course (toutes les voitures, joueur compris), rendu dès que la règle le permet ; une
-- instance précédente arrêtée net (repère ;D de la reprise) : tout est rendu une fois. Sans commandes (app inactive,
-- aucune voiture suivie) : tout est rendu.
function M.drs(a,frame,commands,now)
 if not a.allowed or frame.online or frame.replay or frame.paused then return end
 if a.drsRelease and frame.count>0 then
  for i=1,frame.count do Caps.restoreCall(a.caps,'drs',frame.cars[i].index,false) end
  a.drsRelease=false; a.recoveryDirty=true
 end
 local any=false
 for i=1,frame.count do
  local car=frame.cars[i]; local s=a.cars[i]; local cmd=commands and commands[i]
  local want=cmd~=nil and cmd.drsBlock==true
  if want~=s.drsBlocked then
   if want then if Caps.call(a.caps,'drs',car.index,true) then s.drsBlocked=true; a.recoveryDirty=true end
   elseif Caps.restoreCall(a.caps,'drs',car.index,false) then s.drsBlocked=false; a.recoveryDirty=true end
  end
  any=any or s.drsBlocked
  -- DRS des IA : ouverture demandée par le moteur au plus une fois par seconde par voiture ; fermeture au freinage
  -- aussitôt (quelques essais par seconde au plus).
  local open=cmd and cmd.drsWant
  if open~=nil and car.valid and car.control and not car.player and now>=s.drsAt+(open and K.drsAiRetry or K.drsAiCloseRetry) then
   if Caps.call(a.caps,'drsActive',car.index,open) then s.drsAt=now end
  end
 end
 a.drsAny=any
end
local function releaseDrs(a,frame)
 for i=1,frame.count do local s=a.cars[i]; if s.drsBlocked and Caps.restoreCall(a.caps,'drs',frame.cars[i].index,false) then s.drsBlocked=false; a.recoveryDirty=true end end
 a.drsAny=false
end
M.releaseDrs=releaseDrs
-- Overlay en jeu (Beta 1.25) : case de session d'AC (tour, temps restant, RACE OVER) masquée ou rendue ; taille de
-- l'écran ; messages d'AC écoutés et, sur demande, masqués. Un Disposable de CSP s'appelle pour être annulé.
function M.sessionBox(hide) return callable(ac.disableExtraHUDElements) and pcall(ac.disableExtraHUDElements,'sessionTime',hide)==true end
function M.screen()
 if not callable(ac.getUI) then return nil end
 local ok,s=pcall(ac.getUI)
 if ok and s and s.windowSize and U.finite(s.windowSize.x) and s.windowSize.x>0 then return s.windowSize end
 return nil
end
function M.listenMessages(fn)
 if not callable(ac.onMessage) then return nil end
 local ok,d=pcall(ac.onMessage,fn); return ok and d or nil
end
function M.blockMessages()
 if not callable(ac.blockSystemMessages) then return nil end
 local ok,d=pcall(ac.blockSystemMessages,'.'); return ok and d or nil
end
function M.dispose(d) if type(d)=='function' or callable(d) then pcall(d) end end
-- Journal de session sur disque (Documents/Assetto Corsa/logs) : un fichier par lancement du jeu, trois précédents
-- conservés. Un rechargement de l'app dans le même lancement (repère dans ac.store) poursuit le même fichier.
function M.journalOpen(a)
 a.journalPath=nil; a.journalBytes=0
 local ok=pcall(function()
  if not io or type(io.open)~='function' or not ac.getFolder or not ac.FolderID or not ac.FolderID.Logs then return end
  local root=ac.getFolder(ac.FolderID.Logs)
  if type(root)~='string' or root=='' then return end
  local base=root..'/ACAdvancedIA'
  local continued=M.loadText(K.journalMarker)=='1' and type(io.fileExists)=='function' and io.fileExists(base..'.log')
  if not continued and type(io.fileExists)=='function' and type(io.move)=='function' then
   for n=K.journalKeep-1,1,-1 do local from=base..'.'..n..'.log'; if io.fileExists(from) then io.move(from,base..'.'..(n+1)..'.log',true) end end
   if io.fileExists(base..'.log') then io.move(base..'.log',base..'.1.log',true) end
  end
  local f=io.open(base..'.log',continued and 'a' or 'w'); if not f then return end
  if continued and f.seek then a.journalBytes=tonumber(f:seek('end')) or 0 end
  f:close(); a.journalPath=base..'.log'; M.storeText(K.journalMarker,'1')
 end)
 return ok and a.journalPath~=nil
end
function M.clockText()
 if not os or type(os.date)~='function' then return '----------' end
 local ok,text=pcall(os.date,'%Y-%m-%d %H:%M:%S')
 return ok and type(text)=='string' and text or '----------'
end
function M.journalWrite(a,text)
 if not a.journalPath or type(text)~='string' or text=='' then return false end
 local full=a.journalBytes+#text>K.journalMaxBytes
 if full then text='=== journal limite a '..K.journalMaxBytes..' octets pour ce lancement ===\n' end
 local ok=pcall(function() local f=io.open(a.journalPath,'a'); f:write(text); f:close() end)
 if ok then a.journalBytes=a.journalBytes+#text else a.journalFailures=(a.journalFailures or 0)+1 end
 if full or not ok and a.journalFailures>=K.capabilityFailures or a.journalBytes>=K.journalMaxBytes then a.journalPath=nil end
 return ok
end
function M.storeText(key,text) if ac.store then return pcall(ac.store,key,text) end return false end
function M.loadText(key) if not ac.load then return nil end local ok,text=pcall(ac.load,key); return ok and text or nil end
function M.message(title,text) if callable(ac.setMessage) then return pcall(ac.setMessage,title,text) end return false end
-- Message témoin du masquage des messages d'AC (Beta 1.26), le plus bref possible.
function M.probeMessage(title) if callable(ac.setMessage) then return pcall(ac.setMessage,title,'',nil,K.probeTime) end return false end
-- AI flood de CSP (Beta 1.26) : réglage de l'utilisateur (cfg/extension/new_behaviour.ini, absent tant qu'il n'a rien
-- changé) et défauts de CSP (extension/config/new_behaviour.ini) ; écriture sûre (fichier temporaire, puis remplacement).
local function floodPath(id)
 if not ac.getFolder or not ac.FolderID or not ac.FolderID[id] then return nil end
 local ok,root=pcall(ac.getFolder,ac.FolderID[id])
 return ok and type(root)=='string' and root~='' and root..'\\new_behaviour.ini' or nil
end
function M.floodRead()
 if not io or type(io.load)~='function' then return nil,nil,false end
 local user,system=floodPath('ExtCfgUser'),floodPath('ExtCfgSys')
 if not user then return nil,nil,false end
 local ok,text=pcall(io.load,user)
 local okSystem,defaults=false,nil
 if system then okSystem,defaults=pcall(io.load,system) end
 return ok and type(text)=='string' and text or '',okSystem and type(defaults)=='string' and defaults or nil,ok and type(io.save)=='function'
end
function M.floodWrite(text)
 local path=floodPath('ExtCfgUser')
 if not path or not io or type(io.save)~='function' or type(text)~='string' then return false end
 local ok,done=pcall(io.save,path,text,true)
 return ok and done~=false
end
function M.apply(a,frame,commands,g,now)
 if not a.allowed or frame.online or frame.replay or frame.paused then return end
 a.g=g; a.offsetSign=g.offsetSign
 for i=1,frame.count do
  local car=frame.cars[i]; local cmd=commands[i]; local s=a.cars[i]
  -- Erreur de pilotage décidée par le moteur : servie une seule fois, à une IA en piste, qu'elle soit commandée ou non
  -- (rien à rendre : la fonction native agit pendant la durée donnée).
  local mistake=(cmd.mistakeId or 0)~=(s.mistakeServed or 0); s.mistakeServed=cmd.mistakeId or 0
  if mistake and car.valid and car.control and not car.player and not car.pit and not car.offtrack and i~=a.caps.probeIndex then
   if cmd.mistakeKind=='brake' then Caps.call(a.caps,'brakeMistake',car.index,cmd.mistakeTime)
   else Caps.call(a.caps,'tractionMistake',car.index,cmd.mistakeTime,cmd.mistakeSeverity) end
  end
  weather(a,s,car,cmd,now)
  pitRequest(a,s,car,cmd,now)
  safety(a,s,car,cmd,now)
  startDelay(a,s,car,cmd)
  place(a,s,car,cmd,now)
  recover(a,s,car,cmd)
  hold(a,s,car,cmd,now)
  flash(a,s,car,cmd,now)
  local limit=math.min(cmd.speedLimit or K.unlimitedSpeed,cmd.yellowLimit or K.unlimitedSpeed)
  local wanted=cmd.weatherManaged or cmd.rulePit or cmd.stopHold or cmd.pitHold or cmd.scPark or cmd.scSpeed<K.unlimitedSpeed or s.stop or s.parked or cmd.active and (cmd.levelOwned~=false or cmd.aggressionOwned~=false or cmd.cautionOwned~=false or math.abs(cmd.offset)>=K.offsetEpsilon or (g.useBrakeAssist and (cmd.brake or 0)>0) or limit<K.unlimitedSpeed)
  if not wanted and s.owned and i~=a.caps.probeIndex and i~=a.calibrationIndex then s.reset=true end
  if car.valid and car.control and not car.player and not car.pit and not car.offtrack and cmd.active and wanted and i~=a.caps.probeIndex and not s.reset then
   claim(a,s,car,now)
   if U.finite(cmd.offset) and g.offsetSign~=0 then
    local offset=U.clamp(cmd.offset,-1,1)*g.offsetSign
    if math.abs(offset-s.offset)>=K.offsetEpsilon or s.reset then
     if Caps.call(a.caps,'offset',car.index,offset,offset~=0 and g.overrideAwareness) then if U.sign(s.offset)~=U.sign(offset) then a.recoveryDirty=true end; s.offset=offset; s.reset=false; s.offsetReset=offset==0 end
    end
   elseif not U.finite(cmd.offset) then a.rejected=a.rejected+1 end
   if now-s.lastWrite>=K.writePeriod then
    if not U.finite(cmd.level) or not U.finite(cmd.aggression) or not U.finite(cmd.caution) then a.rejected=math.min(K.counterMax,a.rejected+1) end
    local level=U.number(cmd.level,0,a.caps.levelMode=='native' and 1.1 or 1,s.level or car.aiLevel)
    local previous=s.level
    field(a,s,'level',car.index,cmd.levelOwned,level,K.levelEpsilon,s.originalLevel)
    if s.level~=previous then s.levelAt=now end
    field(a,s,'aggression',car.index,cmd.aggressionOwned,U.number(cmd.aggression,0,K.maxAggression,car.aiAggression),K.aggrEpsilon,s.originalAggression)
    field(a,s,'caution',car.index,cmd.cautionOwned,U.number(cmd.caution,0.5,K.maxCaution,K.defaultCaution),K.cautionEpsilon,K.defaultCaution)
    local grip=K.gripBase; local gripOwned=false
    if g.useGripBoost and a.caps.levelMode=='grip' then grip=grip*(1+math.max(0,U.number(cmd.level,0,1.1,1)*100-100)*g.gripPerLevelPct); gripOwned=true end
    if cmd.weatherManaged and (cmd.weatherGrip or 1)>1 then grip=grip*U.number(cmd.weatherGrip,1,1.3,1); gripOwned=true end
    if gripOwned and a.caps.grip.available then
     send(a,s,'grip',car.index,grip,K.gripEpsilon)
    elseif s.grip then if Caps.restoreCall(a.caps,'grip',car.index,K.gripBase) then s.grip=nil; a.recoveryDirty=true end end
    s.lastWrite=now
   end
   local brake=g.useBrakeAssist and U.number(cmd.brake,0,K.brakeMax,0) or 0
   if a.caps.brake.available and (brake>0 or s.brake>0) then if Caps.call(a.caps,'brake',car.index,brake) then s.brake=brake end end
   local speed=U.number(limit,0,K.unlimitedSpeed,K.unlimitedSpeed)
   if speed<K.unlimitedSpeed then send(a,s,'speed',car.index,speed,K.levelEpsilon)
   elseif s.speed~=nil and Caps.restoreCall(a.caps,'speed',car.index,K.unlimitedSpeed) then s.speed=nil; a.recoveryDirty=true end
   -- L'instantané précède les écritures : seul un niveau écrit lors d'une image précédente est relu,
   -- et seulement s'il dépasse nettement 1 ; un écrêtage se distingue alors de la tolérance de lecture.
   if now>=s.readAt and s.levelAt~=now then s.readAt=now+K.readbackPeriod
    if s.level and s.level>1+K.probeTolerance and car.aiLevel<1+K.probeTolerance then a.caps.native110=false; a.caps.probeDone=true end
   end
  elseif s.brake>0 and a.caps.brake.available and car.valid and car.control and not car.player then
   -- Frein additionnel relâché dès que la voiture n'est plus commandée (stands, hors piste, fin de manœuvre).
   if Caps.restoreCall(a.caps,'brake',car.index,0) then s.brake=0 end
  end
 end
end
function M.register(a,release,session)
 if ac.onRelease and not a.releaseToken then local ok,t=pcall(ac.onRelease,release); if ok then a.releaseToken=t or true end end
 if ac.onSessionStart and not a.sessionToken then local ok,t=pcall(ac.onSessionStart,session); if ok then a.sessionToken=t or true end end
end
function M.unregister(a)
 disposeBeep(a)
 if a.deltaEvent then pcall(function() a.deltaEvent:dispose() end); a.deltaEvent=nil end
 if callable(a.sessionToken) then pcall(a.sessionToken) end
 if callable(a.releaseToken) then pcall(a.releaseToken) end
 a.sessionToken=nil; a.releaseToken=nil
end
function M.nextSession(a,frame)
 M.releaseBlackFlag(a); M.releaseDrs(a,frame)
 for i=1,frame.count do
  local s=a.cars[i]; local car=frame.cars[i]
  if s.owned then
   if s.id~=(car.identity or car.id) then s.owned=false; s.reset=false; s.recovered=false
   else
    -- Une entrée récupérée ne connaît pas la valeur commandée : ses originaux restent ceux sauvegardés.
    if s.level and not s.recovered and math.abs(car.aiLevel-s.level)>K.levelEpsilon then s.originalLevel=car.aiLevel end
    if s.aggression and not s.recovered and math.abs(car.aiAggression-s.aggression)>K.aggrEpsilon then s.originalAggression=car.aiAggression end
    -- Voiture garée (voiture de sécurité, réserve, disqualifiée) : gardée sous l'ordre de garage, que le moteur lève
    -- lui-même ; la restituer la libérerait puis la regarerait à chaque image.
    s.reset=not s.parked; s.tyreVisit=-1
   end
  end
  -- Nouvelle session ou course recommencée : AC replace les voitures sur la grille ; une voiture à garer (voiture de
  -- sécurité, réserve) ou à dépanner est de nouveau ramenée à son stand.
  s.lastWrite=-math.huge; s.readAt=0; s.teleported=false; s.teleportAt=-math.huge; s.redTeleported=false
 end
 a.session=frame.session
end
function M.clipboard(text) if ac.setClipboardText then return pcall(ac.setClipboardText,text) end return false end
function M.checkpoint(a,frame,force)
 if not ac.store or not (a.recoveryDirty or force) or frame.replay then return end
 local rows={tostring(frame.session)..(a.flagOverride and ';F' or '')..(a.drsAny and ';D' or '')}
 for i=1,K.maxCars do
  local s=a.cars[i]
  if s.owned and s.id:match('^[%w_%-]*$') then
   rows[#rows+1]=string.format('%d,%s,%.9g,%.9g,%.9g,%d,%d,%d,%d,%d,%d,%d,%d,%d,%d,%d,%d',i,s.id,s.originalLevel,s.originalAggression,s.offset,s.level and 1 or 0,s.aggression and 1 or 0,s.caution and 1 or 0,s.grip and 1 or 0,s.brake>0 and 1 or 0,s.speed and 1 or 0,s.rainHint~=nil and 1 or 0,s.rainHint==true and 1 or 0,s.originalRain and 1 or 0,s.pitRequest and 1 or 0,s.stop and 1 or 0,s.parked and 1 or 0)
  end
 end
 local ok=pcall(ac.store,'humanai:recovery',table.concat(rows,'\n')); if ok then a.recoveryDirty=false end
end
function M.recover(a,frame)
 if not ac.load then return end
 local ok,text=pcall(ac.load,'humanai:recovery')
 if not ok or type(text)~='string' or #text>K.maxZoneBytes then return end
 -- Drapeau laissé par une instance précédente : rendu à AC quelle que soit la session.
 local head=text:match('^[^\n]*') or ''
 if head:find(';F',1,true) then a.flagOverride=true end
 -- DRS laissé coupé par une instance précédente : rendu à toutes les voitures.
 if head:find(';D',1,true) then a.drsRelease=true end
 local session=text:match('^(%d+)')
 if tonumber(session)~=frame.session then return end
 for slot,id,level,aggression,offset,lc,ag,ca,gr,br,sp,rh,rv,ro,pr,st,pk in text:gmatch('\n(%d+),([%w_%-]*),([%d.eE+%-]+),([%d.eE+%-]+),([%d.eE+%-]+),([01]),([01]),([01]),([01]),([01]),?([01]?),?([01]?),?([01]?),?([01]?),?([01]?),?([01]?),?([01]?)') do
  local i=tonumber(slot); local l,aggressionValue,o=tonumber(level),tonumber(aggression),tonumber(offset)
  if i and i>=1 and i<=K.maxCars and U.finite(l) and l>=0 and l<=2 and U.finite(aggressionValue) and aggressionValue>=0 and aggressionValue<=1 and U.finite(o) and math.abs(o)<=1 then
   local s=a.cars[i]; s.owned=true; s.reset=true; s.recovered=true; s.id=id; s.originalLevel=l; s.originalAggression=aggressionValue; s.offset=o
   s.level=lc=='1' and l or nil; s.aggression=ag=='1' and aggressionValue or nil; s.caution=ca=='1' and 1 or nil; s.grip=gr=='1' and K.gripBase or nil; s.brake=br=='1' and K.brakeMax or 0
   s.speed=sp=='1' and K.unlimitedSpeed or nil
   s.offsetReset=o==0
   if rh=='1' then s.rainHint=rv=='1' end; s.originalRain=ro=='1'; s.pitRequest=pr=='1'; s.stop=st=='1'; s.parked=pk=='1'
  end
 end
end
return M
